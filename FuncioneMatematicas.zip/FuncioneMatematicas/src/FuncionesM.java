import java.util.Scanner;

public class FuncionesM {
	
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		double base, exponente;
		System.out.println("Introduce la base");
		base = sc.nextDouble();
		System.out.println("Introduce el Exponente");
		exponente = sc.nextDouble();
					
		double resultado = Math.pow(base,exponente)-1;
		System.out.println(resultado);
	}	
	
}
